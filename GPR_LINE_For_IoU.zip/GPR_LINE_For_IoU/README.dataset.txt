# GPR_LINE > 2024-05-24 2:46pm
https://universe.roboflow.com/smart-gio-lab/gpr_line

Provided by a Roboflow user
License: CC BY 4.0

